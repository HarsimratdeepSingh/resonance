(() => {
  const $ = selector => document.querySelector(selector);
  const params = new URLSearchParams(location.search);
  const roomFromUrl = (params.get("room") || "").toUpperCase();
  const isHost = params.get("host") === "1";
  let socket = null;
  let chosenZone = "A";
  let connected = false;
  let soundEnabled = true;
  let audioContext = null;
  let currentColor = "#172033";
  const zoneColors = { A: "#172033", B: "#172033" };
  let reconnectTimer = null;
  let deviceId = getDeviceId();

  function getDeviceId() {
    try {
      let id = localStorage.getItem("resonance-device-id");
      if (!id) {
        id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2);
        localStorage.setItem("resonance-device-id", id);
      }
      return id;
    } catch {
      return Math.random().toString(36).slice(2);
    }
  }

  function show(id) {
    ["#home", "#host", "#join"].forEach(selector => $(selector).classList.add("hidden"));
    $(id).classList.remove("hidden");
  }

  function setHostStatus(online, text) {
    const el = $("#host-status");
    el.classList.toggle("online", online);
    el.querySelector("span").textContent = text;
  }

  function connect(room, role, key = "", zone = "A") {
    if (socket && socket.readyState === WebSocket.OPEN) socket.close();
    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    const query = new URLSearchParams({ room, role, zone });
    if (key) query.set("key", key);
    if (role === "attendee") query.set("id", deviceId);
    socket = new WebSocket(`${protocol}//${location.host}/ws?${query}`);

    socket.addEventListener("open", () => {
      connected = true;
      if (role === "host") setHostStatus(true, "Connected");
      else {
        $("#attendee-status").classList.add("online");
        $("#attendee-status").innerHTML = "<i></i>Connected";
      }
    });

    socket.addEventListener("message", event => {
      let data;
      try { data = JSON.parse(event.data); } catch { return; }
      if (data.action === "error") {
        if (role === "attendee") $("#join-error").textContent = data.message;
        else setHostStatus(false, data.message);
      } else if (data.action === "counts" && role === "host") {
        renderCounts(data);
      } else if (data.action === "cue" && role === "attendee") {
        applyCue(data);
      } else if (data.action === "cue-sent" && role === "host") {
        const target = data.target === "all" ? "Everyone" : `Zone ${data.target}`;
        $("#cue-feedback").textContent = `${data.label} sent to ${data.deliveredTo} phone${data.deliveredTo === 1 ? "" : "s"} in ${target}.`;
      } else if (data.action === "zone-set" && role === "attendee") {
        $("#attendee-zone").textContent = `ZONE ${data.zone}`;
      }
    });

    socket.addEventListener("close", () => {
      connected = false;
      if (role === "host") {
        setHostStatus(false, "Reconnecting");
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => connect(room, role, key, zone), 1800);
      } else if (!$("#attendee-stage").classList.contains("hidden")) {
        $("#attendee-status").classList.remove("online");
        $("#attendee-status").innerHTML = "<i></i>Reconnecting";
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => connect(room, role, "", chosenZone), 1800);
      }
    });
  }

  async function startShow() {
    const button = $("#create-show");
    button.disabled = true;
    button.textContent = "Starting…";
    try {
      const response = await fetch("/api/rooms", { method: "POST" });
      if (!response.ok) throw new Error("Could not create a show.");
      const { room, hostKey } = await response.json();
      location.href = `/?host=1&room=${encodeURIComponent(room)}&key=${encodeURIComponent(hostKey)}`;
    } catch (error) {
      button.disabled = false;
      button.innerHTML = "Start a show <span>→</span>";
      alert(error.message || "Could not start show. Please try again.");
    }
  }

  function openJoin(room) {
    if (!room || room.length !== 6) {
      $("#join-error").textContent = "Enter the 6-character show code.";
      return;
    }
    location.href = `/?room=${encodeURIComponent(room)}`;
  }

  function joinURL(room) {
    return `${location.origin}/?room=${encodeURIComponent(room)}`;
  }

  function renderCounts(data) {
    $("#online-count").textContent = data.online;
    $("#zone-a-count").textContent = data.zones.A;
    $("#zone-b-count").textContent = data.zones.B;
    $("#device-summary").textContent = data.online
      ? `${data.online} phone${data.online === 1 ? "" : "s"} connected`
      : "Waiting for guests";
    const grid = $("#device-grid");
    const empty = $("#empty-state");
    if (!data.devices.length) {
      grid.innerHTML = "";
      grid.appendChild(empty);
      return;
    }
    grid.innerHTML = "";
    data.devices.forEach((device, index) => {
      const card = document.createElement("div");
      card.className = "device-card";
      card.style.setProperty("--device-color", zoneColors[device.zone] || currentColor);
      const phone = document.createElement("div");
      phone.className = "phone-shape";
      const label = document.createElement("span");
      label.className = "device-label";
      label.textContent = `Phone ${String(index + 1).padStart(2, "0")}`;
      const zone = document.createElement("span");
      zone.className = "device-zone";
      zone.textContent = `ZONE ${device.zone}`;
      card.append(phone, label, zone);
      grid.appendChild(card);
    });
  }

  function sendCue(color, label, action = "cue") {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      $("#cue-feedback").textContent = "Producer is reconnecting. Try again in a moment.";
      return;
    }
    const target = $("#target-select").value;
    const displayColor = action === "clear" ? "#172033" : color;
    (target === "all" ? ["A", "B"] : [target]).forEach(zone => {
      zoneColors[zone] = displayColor;
    });
    socket.send(JSON.stringify({
      action,
      target,
      color: displayColor,
      label,
      tone: action === "cue" && $("#tone-toggle").checked
    }));
    if (action === "clear") $("#cue-feedback").textContent = "Clear cue sent.";
  }

  function ensureAudio() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    try {
      if (!audioContext) audioContext = new AudioCtx();
      if (audioContext.state === "suspended") audioContext.resume();
    } catch {}
  }

  function playTone() {
    if (!soundEnabled || !audioContext) return;
    try {
      const now = audioContext.currentTime;
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(660, now);
      oscillator.frequency.exponentialRampToValueAtTime(880, now + 0.12);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.075, now + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start(now);
      oscillator.stop(now + 0.34);
    } catch {}
  }

  function applyCue(data) {
    currentColor = data.color || "#172033";
    document.documentElement.style.setProperty("--orb-color", currentColor);
    $("#attendee-stage").style.backgroundColor = currentColor;
    $("#light-orb").style.setProperty("--orb-color", currentColor);
    $("#cue-label").textContent = data.label || "Live cue";
    if (data.tone) playTone();
  }

  function enterAttendee() {
    $("#join-error").textContent = "";
    ensureAudio();
    $("#join-setup").classList.add("hidden");
    $("#attendee-stage").classList.remove("hidden");
    $("#attendee-zone").textContent = `ZONE ${chosenZone}`;
    connect(roomFromUrl, "attendee", "", chosenZone);
  }

  function init() {
    document.querySelectorAll(".color-button[data-color]").forEach(button => {
      button.addEventListener("click", () => sendCue(button.dataset.color, button.dataset.label));
    });
    $("#clear-cue").addEventListener("click", () => sendCue("#172033", "Screens cleared", "clear"));
    $("#sound-button").addEventListener("click", () => {
      soundEnabled = !soundEnabled;
      $("#sound-button").innerHTML = soundEnabled ? "♫ <span>Sound on</span>" : "♫ <span>Sound off</span>";
      if (soundEnabled) ensureAudio();
    });

    if (isHost && roomFromUrl) {
      show("#host");
      $("#room-code").textContent = roomFromUrl;
      const url = joinURL(roomFromUrl);
      $("#join-url").textContent = url;
      $("#qr-image").src = `/api/qr?text=${encodeURIComponent(url)}`;
      $("#copy-link").addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(url);
          $("#copy-link").textContent = "Copied!";
          setTimeout(() => $("#copy-link").textContent = "Copy join link", 1500);
        } catch {
          window.prompt("Copy this join link:", url);
        }
      });
      connect(roomFromUrl, "host", params.get("key") || "");
      return;
    }

    if (roomFromUrl) {
      show("#join");
      document.querySelectorAll(".zone-choice").forEach(button => {
        button.addEventListener("click", () => {
          chosenZone = button.dataset.zone;
          document.querySelectorAll(".zone-choice").forEach(item => item.classList.toggle("selected", item === button));
        });
      });
      $("#connect-device").addEventListener("click", enterAttendee);
      return;
    }

    show("#home");
    $("#create-show").addEventListener("click", startShow);
    $("#join-show").addEventListener("click", () => openJoin($("#room-input").value.trim().toUpperCase()));
    $("#room-input").addEventListener("keydown", event => {
      if (event.key === "Enter") openJoin($("#room-input").value.trim().toUpperCase());
    });
    $("#room-input").addEventListener("input", event => {
      event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    });

  }

  init();
})();